/*
John Cordwell III
Project 4
This program finds an optimal path given a start and end node on a grid matrix using Djikstra's algorithm.
*/

#include <iostream>
#include <vector>
#include <queue>
#include <unordered_map>
#include <chrono>         // time
#include <sys/resource.h> // memory usage

struct Node
{
    int row;
    int col;
    int cost;

    bool operator>(const Node &other) const
    {
        return cost > other.cost;
    }
};

std::vector<std::pair<int, int>> directions = {{-1, 0}, {1, 0}, {0, -1}, {0, 1}}; // possible moves (up, down, left, right)

int main()
{
    // time
    // auto startTime = std::chrono::high_resolution_clock::now();

    int tileCount;
    std::cin >> tileCount; // unique tiles

    std::unordered_map<char, int> tileCosts;
    for (int i = 0; i < tileCount; ++i)
    {
        char tile_name;
        int tileCost; // tile value
        std::cin >> tile_name >> tileCost;
        tileCosts[tile_name] = tileCost;
    }

    int mapRows; // map dimensions
    int mapCols;
    std::cin >> mapRows >> mapCols;

    std::vector<std::vector<char>> map(mapRows, std::vector<char>(mapCols)); // map layout
    for (int i = 0; i < mapRows; ++i)
    {
        for (int j = 0; j < mapCols; ++j)
        {
            std::cin >> map[i][j];
        }
    }

    int startRow;
    int startCol;
    int endRow;
    int endCol;

    std::cin >> startRow >> startCol; // read start and end positions
    std::cin >> endRow >> endCol;

    // Dijkstra's algorithm
    std::vector<std::vector<int>> dist(mapRows, std::vector<int>(mapCols, -1));                                       // create 2d vector and initialize to -1
    std::vector<std::vector<std::pair<int, int>>> prev(mapRows, std::vector<std::pair<int, int>>(mapCols, {-1, -1})); // 2d vector to store previous node for backtracking
    std::priority_queue<Node, std::vector<Node>, std::greater<Node>> pq;                                              // priority queue

    // initialize the starting point
    dist[startRow][startCol] = tileCosts[map[startRow][startCol]];
    pq.push({startRow, startCol, dist[startRow][startCol]});

    while (!pq.empty())
    {
        Node node = pq.top();
        pq.pop();

        int r = node.row, c = node.col;

        if (r == endRow && c == endCol)
            break;

        for (const auto &direction : directions) // for exploration
        {
            int dr = direction.first;
            int dc = direction.second;
            int nr = r + dr;
            int nc = c + dc;

            if (nr >= 0 && nr < mapRows && nc >= 0 && nc < mapCols)
            {
                int new_dist = dist[r][c] + tileCosts[map[nr][nc]];

                if (dist[nr][nc] == -1 || new_dist < dist[nr][nc]) // only need to update if it's the first time at the node or there's a new path
                {
                    dist[nr][nc] = new_dist;
                    pq.push({nr, nc, new_dist});
                    prev[nr][nc] = {r, c}; // path tracking
                }
            }
        }
    }

    // path reconstruction
    std::vector<std::pair<int, int>> path;
    int currRow = endRow, currCol = endCol;

    while (currRow != startRow || currCol != startCol) // backtrack from the end to the start
    {
        path.push_back({currRow, currCol});
        std::tie(currRow, currCol) = prev[currRow][currCol];
    }
    path.push_back({startRow, startCol});

    std::cout << dist[endRow][endCol] - tileCosts[map[endRow][endCol]] << "\n"; // total cost minus end tile cost

    for (auto it = path.rbegin(); it != path.rend(); ++it) // path in reverse order
    {
        std::cout << it->first << " " << it->second << "\n";
    }

    // timing
    // auto endTime = std::chrono::high_resolution_clock::now();
    // std::chrono::duration<double> elapsed = endTime - startTime;
    // std::cout << "Elapsed time: " << elapsed.count() << " seconds\n";

    // memory usage
    // struct rusage usage;
    // getrusage(RUSAGE_SELF, &usage);
    // std::cout << "Memory usage: " << usage.ru_maxrss << " KB\n"; // Memory usage in kilobytes

    return 0;
}
