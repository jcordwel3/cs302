/*
John Cordwell III
Project 4
This program generates a random square board given a int for length and width.
*/

#include <iostream>
#include <vector>
#include <cstdlib> // rand() and srand()
#include <ctime>   // time

int main(int argc, char *argv[])
{
    int N = std::atoi(argv[1]); // command-line argument to int

    srand(time(0));

    std::vector<std::pair<char, int>> tiles = {
        {'f', 3},
        {'g', 1},
        {'G', 2},
        {'h', 4},
        {'m', 7},
        {'r', 5}};

    std::cout << tiles.size() << std::endl; // output

    for (const auto &tile : tiles) // tile output and cost
    {
        std::cout << tile.first << " " << tile.second << std::endl;
    }

    std::cout << N << " " << N << std::endl; // grid dimensions

    for (int i = 0; i < N; ++i) // random tiles for matrix
    {
        for (int j = 0; j < N; ++j)
        {
            char randomTile = tiles[rand() % tiles.size()].first; // random select
            std::cout << randomTile;
            if (j != N - 1)
            {
                std::cout << " ";
            }
        }
        std::cout << std::endl;
    }

    std::cout << "0 0" << std::endl;                 // start
    std::cout << N - 1 << " " << N - 1 << std::endl; // end

    return 0;
}
