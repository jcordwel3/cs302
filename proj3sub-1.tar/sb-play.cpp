/*
John Cordwell III
10/04/24
Project 03

sb-play.cpp plays Superball (either swapping or scoring
cells/clusters) and gets roughly 322 points on average after 100 games.
*/

#include <iostream>
#include <vector>
#include <algorithm>
#include "disjoint.h"

using namespace std;

class Superball
{
public:
  Superball(int argc, char **argv);
  void read_board();
  void find_best_move();

  int r, c, mss, empty; // rows, columns, minimum score size, and empty cells
  vector<int> board;
  vector<int> goals;  // scoring cells
  vector<int> colors; // different color values

private:
  void find_scoring_sets();
  void make_optimized_swap();
  int calculate_cluster_size(int r1, int c1, int r2, int c2);
  int evaluate_board();
  void swap_cells(int r1, int c1, int r2, int c2);
};

Superball::Superball(int argc, char **argv)
{
  if (argc != 5)
  {
    cerr << "Usage: my-play rows cols min-score-size colors" << endl;
    exit(1);
  }

  r = atoi(argv[1]);   // rows
  c = atoi(argv[2]);   // columns
  mss = atoi(argv[3]); // minimum score size

  colors = vector<int>(256, 0);
  for (int i = 0; argv[4][i] != '\0'; i++)
  {
    colors[argv[4][i]] = i + 2; // for color value
  }

  board = vector<int>(r * c, '.');
  goals = vector<int>(r * c, 0);
  empty = 0;

  read_board();
}

void Superball::read_board()
{
  char ch;
  for (int i = 0; i < r; i++)
  {
    for (int j = 0; j < c; j++)
    {
      cin >> ch;
      board[i * c + j] = ch;
      if (ch == '.' || ch == '*')
      {
        empty++; // counts empty cells
        if (ch == '*')
        {
          goals[i * c + j] = 1; // marks goal cells
        }
      }
      else if (isupper(ch))
      {
        board[i * c + j] = tolower(ch); // to lowercase
        goals[i * c + j] = 1;           // goal cells
      }
    }
  }
}

void Superball::find_best_move()
{
  find_scoring_sets();   // step 1: find scoring move
  make_optimized_swap(); // step 2: if no scoring moves, make an optimized swap
}

// Finds scoring sets of clusters on the board
void Superball::find_scoring_sets()
{
  DisjointSetByRankWPC ds(r * c);
  vector<int> size(r * c, 0);

  for (int i = 0; i < r; i++)
  {
    for (int j = 0; j < c; j++)
    {
      if (board[i * c + j] != '.' && board[i * c + j] != '*')
      {
        int element = i * c + j;
        if (i > 0 && board[i * c + j] == board[(i - 1) * c + j])
        {
          int root1 = ds.Find(element);
          int root2 = ds.Find((i - 1) * c + j);
          if (root1 != root2)
          {
            ds.Union(root1, root2);
          }
        }
        if (j > 0 && board[i * c + j] == board[i * c + (j - 1)])
        {
          int root1 = ds.Find(element);
          int root2 = ds.Find(i * c + (j - 1));
          if (root1 != root2)
          {
            ds.Union(root1, root2);
          }
        }
      }
    }
  }

  // count component size
  for (int i = 0; i < r * c; i++)
  {
    if (board[i] != '.' && board[i] != '*')
    {
      size[ds.Find(i)]++;
    }
  }

  // find score and print
  for (int i = 0; i < r * c; i++)
  {
    if (size[ds.Find(i)] >= mss && goals[i])
    {
      cout << "SCORE " << i / c << " " << i % c << endl;
      return;
    }
  }
}

void Superball::make_optimized_swap()
{
  int max_board_score = -1;
  int best_r1 = -1, best_c1 = -1, best_r2 = -1, best_c2 = -1;

  // search every possible cell swap
  for (int i = 0; i < r; i++)
  {
    for (int j = 0; j < c; j++)
    {
      if (board[i * c + j] != '.' && board[i * c + j] != '*')
      {
        for (int k = 0; k < r; k++)
        {
          for (int l = 0; l < c; l++)
          {
            if ((i != k || j != l) && board[k * c + l] != '.' && board[k * c + l] != '*')
            {
              // perform a temporary swap
              swap_cells(i, j, k, l);
              int board_score = evaluate_board();

              // added weight to encourage clusters next to the scoring cells
              for (int m = 0; m < r * c; m++)
              {
                if (goals[m] && board[m] != '.' && board[m] != '*')
                {
                  board_score += size_t(1.5 * colors[board[m]]);
                }
              }

              swap_cells(i, j, k, l);

              // best moves
              if (board_score > max_board_score)
              {
                max_board_score = board_score;
                best_r1 = i;
                best_c1 = j;
                best_r2 = k;
                best_c2 = l;
              }
            }
          }
        }
      }
    }
  }

  // perform best move
  if (best_r1 != -1 && best_c1 != -1 && best_r2 != -1 && best_c2 != -1)
  {
    cout << "SWAP " << best_r1 << " " << best_c1 << " " << best_r2 << " " << best_c2 << endl;
  }
}

void Superball::swap_cells(int r1, int c1, int r2, int c2)
{
  swap(board[r1 * c + c1], board[r2 * c + c2]);
}

int Superball::evaluate_board()
{
  DisjointSetByRankWPC ds(r * c);
  vector<int> size(r * c, 0);
  int score = 0;

  // union ops
  for (int i = 0; i < r; i++)
  {
    for (int j = 0; j < c; j++)
    {
      if (board[i * c + j] != '.' && board[i * c + j] != '*')
      {
        int element = i * c + j;

        if (i > 0 && board[i * c + j] == board[(i - 1) * c + j])
        {
          int root1 = ds.Find(element);
          int root2 = ds.Find((i - 1) * c + j);
          if (root1 != root2)
          {
            ds.Union(root1, root2);
          }
        }
        if (j > 0 && board[i * c + j] == board[i * c + (j - 1)])
        {
          int root1 = ds.Find(element);
          int root2 = ds.Find(i * c + (j - 1));
          if (root1 != root2)
          {
            ds.Union(root1, root2);
          }
        }
      }
    }
  }

  // count size and evaluate score
  for (int i = 0; i < r * c; i++)
  {
    if (board[i] != '.' && board[i] != '*')
    {
      int root = ds.Find(i);
      size[root]++; // then add to size
    }
  }

  // find total score
  for (int i = 0; i < r * c; i++)
  {
    if (goals[i] && size[ds.Find(i)] >= mss)
    {
      // based on size and value of color
      score += size[ds.Find(i)] * colors[board[i]];
    }
  }

  return score;
}

int main(int argc, char **argv)
{
  Superball s(argc, argv);
  s.find_best_move();
  return 0;
}
