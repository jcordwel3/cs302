/*
John Cordwell III
10/04/24
Project 03

sb-analyze.cpp analyzes Superball game data,
recognizes connected color clusters and possible
scores then outputs data.
*/

#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <ctype.h>
#include <iostream>
#include <vector>
#include <algorithm>
#include <iomanip>
using namespace std;

#define talloc(type, num) (type *)malloc(sizeof(type) * (num))

class DisjointSet
{
public:
  DisjointSet(int n) : parent(n), rank(n, 0)
  {
    for (int i = 0; i < n; ++i)
    {
      parent[i] = i; // each element starts as its own parent
    }
  }

  int find(int x)
  {
    if (parent[x] != x)
    {
      parent[x] = find(parent[x]); // find root and compress path recursively
    }
    return parent[x];
  }

  // merge by rank
  void union_sets(int x, int y)
  {
    int rootX = find(x);
    int rootY = find(y);

    if (rootX != rootY)
    {
      if (rank[rootX] > rank[rootY])
      {
        parent[rootY] = rootX; // rootY below rootX
      }
      else if (rank[rootX] < rank[rootY])
      {
        parent[rootX] = rootY; // rootX below rootY
      }
      else
      {
        parent[rootY] = rootX; // rootY below rootX and increase rank
        rank[rootX]++;
      }
    }
  }

private:
  vector<int> parent;
  vector<int> rank;
};

class Superball
{
public:
  Superball(int argc, char **argv);
  void analyze_superball();

  int r;     // rows
  int c;     // columns
  int mss;   // minimum score size
  int empty; // empty cells
  vector<int> board;
  vector<int> goals;
  vector<int> colors;
};

// usage
void usage(const char *s)
{
  fprintf(stderr, "usage: sb-analyze rows cols min-score-size colors\n");
  if (s != NULL)
    fprintf(stderr, "%s\n", s);
  exit(1);
}

Superball::Superball(int argc, char **argv)
{
  int i, j;
  string s;

  if (argc != 5)
    usage(NULL);

  if (sscanf(argv[1], "%d", &r) == 0 || r <= 0)
    usage("Bad rows");
  if (sscanf(argv[2], "%d", &c) == 0 || c <= 0)
    usage("Bad cols");
  if (sscanf(argv[3], "%d", &mss) == 0 || mss <= 0)
    usage("Bad min-score-size");

  // ensures unique letters
  colors.resize(256, 0);
  for (i = 0; i < strlen(argv[4]); i++)
  {
    if (!isalpha(argv[4][i]))
      usage("Colors must be distinct letters");
    if (!islower(argv[4][i]))
      usage("Colors must be lowercase letters");
    if (colors[argv[4][i]] != 0)
      usage("Duplicate color");
    colors[argv[4][i]] = 2 + i;
    colors[toupper(argv[4][i])] = 2 + i;
  }

  board.resize(r * c);
  goals.resize(r * c, 0);
  empty = 0;

  // read board
  for (i = 0; i < r; i++)
  {
    if (!(cin >> s))
    {
      fprintf(stderr, "Bad board: not enough rows on standard input\n");
      exit(1);
    }
    if (s.size() != c)
    {
      fprintf(stderr, "Bad board on row %d - wrong number of characters.\n", i);
      exit(1);
    }
    for (j = 0; j < c; j++)
    {
      if (s[j] != '*' && s[j] != '.' && colors[s[j]] == 0)
      {
        fprintf(stderr, "Bad board row %d - bad character %c.\n", i, s[j]);
        exit(1);
      }
      board[i * c + j] = s[j];
      if (board[i * c + j] == '.' || board[i * c + j] == '*')
        empty++;
      if (isupper(board[i * c + j]) || board[i * c + j] == '*')
      {
        goals[i * c + j] = 1; // goal cell
        board[i * c + j] = tolower(board[i * c + j]);
      }
    }
  }
}

void Superball::analyze_superball()
{
  DisjointSet ds(r * c);

  // disjoint sets for touching cells with the same color
  for (int i = 0; i < r; ++i)
  {
    for (int j = 0; j < c; ++j)
    {
      int index = i * c + j;
      if (board[index] == '.' || board[index] == '*')
        continue;

      // right union
      if (j + 1 < c && board[index] == board[index + 1])
      {
        ds.union_sets(index, index + 1);
      }
      // bottom union
      if (i + 1 < r && board[index] == board[index + c])
      {
        ds.union_sets(index, index + c);
      }
    }
  }

  // maps root to size and keeps track of goal cells
  vector<int> set_size(r * c, 0);
  vector<int> goal_cells(r * c, -1);
  for (int i = 0; i < r; ++i)
  {
    for (int j = 0; j < c; ++j)
    {
      int index = i * c + j;
      if (board[index] == '.' || board[index] == '*')
        continue;

      int root = ds.find(index);
      set_size[root]++;
      if (goals[index] == 1)
      {
        goal_cells[root] = index;
      }
    }
  }

  cout << "Scoring sets:" << endl;
  for (int i = 0; i < r * c; ++i)
  {
    if (set_size[i] >= mss && goal_cells[i] != -1)
    {
      int row = goal_cells[i] / c;
      int col = goal_cells[i] % c;
      cout << "  Size: " << setw(2) << set_size[i]
           << "  Char: " << (char)board[i]
           << "  Scoring Cell: " << row << "," << col << endl;
    }
  }
}

int main(int argc, char **argv)
{
  Superball *s = new Superball(argc, argv);
  s->analyze_superball();
  delete s;
}
